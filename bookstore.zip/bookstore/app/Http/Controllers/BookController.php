<?php

namespace App\Http\Controllers;


class BookController extends Controller
{
    function sayHello(){
        return 'Hello Laravel';
    }
}

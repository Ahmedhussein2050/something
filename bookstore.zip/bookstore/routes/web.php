<?php

use Illuminate\Support\Facades\Route;


Route::get('books', [BookController::class, 'books']);